# Brief decision

One-slide standalone explainer for novice developers and technical executives. The domain mechanism is primary; Intel-rats remains a small project lens.
