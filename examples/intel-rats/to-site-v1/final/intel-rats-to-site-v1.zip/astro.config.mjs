import { defineConfig } from 'astro/config';

export default defineConfig({
  output: 'static',
  site: 'https://example.invalid/intel-rats/',
  trailingSlash: 'always',
});
