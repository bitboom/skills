# Storyboard v01

Headline: Intel TDX 원격 증명은 검증된 VM에만 비밀 공개를 허용한다.

Dominant: left-to-right causal pipeline. Separate collateral rail above; explicit QGS/TDQE boundary; Verifier-signed Result before RP/KMS release.

Supports: proof/non-proof and owner/next action with a small Intel-rats teaching lens.
